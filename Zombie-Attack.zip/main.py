print("You are inside of a storage building hiding from the zombies outside. There aren't very many things around since it's a factory for stuffed bears. You can hear them at the doors. You look around and find a few things that could be used as a weapon. To the left there is a metal pipe. To the right there is a knife. Which will you chose?")

var_1 = input("Type left or right (no caps): ")

if (var_1 == "left"):
  print("They burst through the doors with you in their sights. You pick up the pipe to your left and swing it furiously toward the zombies, hitting heads here and there. you burst through the doors and run towards the parking lot. There are only 2 vehicals that haven't been destroyed. On the left is a motorcycle and on the right is a golf cart. There is a small hole in the fencing around the building, but it is an unlikley escape. You only have enough time to choose one and go.")
  
  var_2 = input("Type left or right: ")
  if (var_2 == "left"): 
    print("The zombies are right on your tail. You jump on the motorcylce, but it doesn't start. You look back to the storage building for a way out, but it's too late. You die trying to look like a badass.")
  elif (var_2 == "right"):
    print("The zombies are right on your tail. You jump into the golf cart, but it's been terribly dammaged and as soon as you start the engine... it blows up. You die an extravagant death.")
  else:
    print("The zombies are right on your tail. You run towards the the fence and dive for the small gap. You clear it and jump to your feet. You can see a road in the distance, maybe that will lead to a country house or some kind on civilization. you've been walking this path for about an hour. The zombies had drifted off some time ago and the sun is brutaliy beating down. You appraoch a fork in the road.")
    
    var_3 = input("Type left or right: ")
    if (var_3 == "left"):
      print("You take the path to the left. You walk for an hour, 2 hours, 3 hours. You drop dead on the road.")
    elif (var_3 == "right"):
      print("You take the path to the right and after about an hour of walking come across a Country house. The sun has gone down and you are exughsted from your journey. Your stomach growls for food. You scavange the kitchen and find a single can of beans. The stove seems to be a gas stove so it could still possibly work. you cook the beans and eat them happily. Your eyes start to droop with sleep, but the house is not yet secure. To the left is the stairs to the bedroom and to the right is the door to the garage. Are you going to sleep or are you going to stay up and secure the house?")
      var_4 = ("Type left or right: ")
      
      if (var_4 == "left"):
        print("You go to the bedroom and try to sleep awy your problems. You didn't secure the house so a horde of zombie come in and attack you in your sleep.")
      
      elif (var_4 == "right"):
        print("Hello Darkness My Old Friend!!!!!!")
      
      else:
        print("You decide to just sit down on the couch and let your life waste away.")
    else:
      print("You don't want to conitue your journy anymore so you sit down and let the natural elemnts take over. You die and become a skeleton covered in sand.")

elif (var_1 == "right"):
  print("They burst through the doors with you in their sights. You pick up the knife to your right, now realizing that it is only 3 inches long. You try your best to stab each zombie in the brain, but there are just too many. You die courageously in the storage building.")

else:
  print ("They burst through the doors with you in their sights. You choose to not pick a weapon and fight with your bare fists. Sadly this leads to your stubborn death as they tear you apart piece by piece like, well, a stuffed bear.")